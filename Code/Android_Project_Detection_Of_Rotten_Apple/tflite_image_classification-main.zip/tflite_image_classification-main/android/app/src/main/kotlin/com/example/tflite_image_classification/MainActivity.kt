package com.example.tflite_image_classification

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
